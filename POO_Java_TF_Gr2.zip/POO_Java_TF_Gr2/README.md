# POO_Java_TF_Gr2

Proyecto final de Programación Orientada a Objetos (Java): gestión de proyectos con interfaz gráfica (Swing).

## Estructura

```
POO_Java_TF_Gr2/
├── pom.xml
└── src/main/java/
    ├── Modelo/
    │   ├── Proyecto.java
    │   ├── Empleado.java
    │   ├── Cliente.java        (abstracta)
    │   ├── Empresa.java        (final, hereda de Cliente)
    │   ├── PersonaNatural.java (final, hereda de Cliente)
    │   └── Contacto.java
    └── Vista/
        └── UsaProyecto.java    (JFrame, clase principal)
```

## Cómo ejecutar

- **NetBeans**: File → Open Project → seleccionar la carpeta `POO_Java_TF_Gr2` → Run (F6).
- **Terminal**: `mvn compile exec:java`

## Notas

- Las clases implementan `Serializable` para poder guardarse en archivos de objetos (`datosProyectos`, `datosClientes`).
- Código del proyecto: `año-consecutivo` (ej. `2026-001`); el consecutivo reinicia cada año.
